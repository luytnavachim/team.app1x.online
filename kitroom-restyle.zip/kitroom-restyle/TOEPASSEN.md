# Kitroom restyle — toepassen op team.app1x.online

Repo: `github.com/luytnavachim/team.app1x.online`
Basis: commit `a5ebf5e` (de enige commit in de repo op moment van maken).

## Wat er in deze zip zit

| Bestand | Doel |
|---|---|
| `index.php` | Volledig vervangen. Bevat de nieuwe styling, header en inline logo. |
| `README.md` | Volledig vervangen. Alleen de merknaam is aangepast. |
| `restyle-kitroom.patch` | Dezelfde wijziging als git-patch, voor wie liever `git am` gebruikt. |
| `kitroom-logo.svg` | Het logo los, vector, limoen (#C8FF3D). Zit al inline in index.php — dit is voor extern gebruik. |
| `kitroom-favicon.svg` | Favicon-versie met donkere afgeronde achtergrond. Zit al als data-URI in index.php. |

## Toepassen — twee routes

**Route A (patch, houdt de git-historie netjes):**

```bash
git checkout -b restyle-kitroom
git am < restyle-kitroom.patch
```

**Route B (bestanden overschrijven):**

kopieer `index.php` en `README.md` over de bestaande bestanden heen, commit.

Beide routes geven exact hetzelfde resultaat.

## Belangrijk: niet aanpassen

De restyle raakt **alleen** presentatie. Deze dingen zijn bewust ongewijzigd en
moeten dat blijven:

- Alle database-queries en de opbouw van `$players`, `$staff`, `$types`, `$gaps`,
  `$orderGroups`, `$dist`.
- De scout-koppeling (`loadScoutPortal`, `findScoutForPlayer`, `syncPlayersFromScout`).
- De pincode-flow, sessies en CSRF in `boot.php` en `save.php`.
- De CSV-export, op de bestandsnaam na (`rohda-14-2-bestellijst.csv` →
  `kitroom-14-2-bestellijst.csv`).

De enige toegevoegde PHP-expressie is de breedte van de voortgangsbalk in het
statistiekblok:

```php
<?= count($active) ? round(100 * $complete / count($active)) : 0 ?>%
```

`boot.php`, `save.php`, `config.example.php` en `.htaccess` zijn **niet** gewijzigd
en zitten daarom niet in deze zip.

## Wat er visueel veranderd is

- Merknaam ROHDA 14-2 → **Kitroom**, ondertitel `14-2 · kleding & selectie`.
  Geen clubnaam, clubkleuren of clublogo meer in de pagina.
- Donker thema: antraciet (`#0F1216` / `#171B21`) met limoen accent (`#C8FF3D`).
- Statuskleuren nu drie in plaats van twee: groen = in bezit, amber = besteld
  (`status = pending`), rood = ontbreekt.
- Navigatie scrollt horizontaal op mobiel en blijft sticky, in plaats van over
  drie regels te wrappen.
- Voortgangsbalk onder "set ontvangen".
- Spelerskolom in de matrix blijft staan bij horizontaal scrollen
  (`position: sticky` op `td.name` / `th.name`).
- Grotere maat-dropdowns en knoppen in bewerkmodus.
- `@media print` zet alles terug naar wit met zwarte tekst, inclusief het logo.

## Controles die al gedaan zijn

- `php -l index.php` — geen syntaxfouten (PHP 8.4).
- Gerenderd met nepdata (17 spelers, staf, catalogus) in leesmodus én
  bewerkmodus, zonder PHP-warnings.
- Bekeken op 1280px, 390px (telefoon) en in printweergave.

## Nog te doen bij deployment

- Cache: `.htaccess` stuurt al `no-cache` voor `.php`, dus een harde refresh
  zou niet nodig moeten zijn.
- Het logo zit inline plus als favicon-data-URI; er hoeven geen losse
  afbeeldingsbestanden op de server te staan.
